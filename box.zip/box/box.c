#include "box.h"

void enter()
{
    
     w1 = (struct box *)malloc(size * sizeof(struct box));
    struct box pw[3]
    = {
        {1,"red"},
        {2,"blue"},
        {3, "black"}
    };
    free(w1);
}



struct box print_details(struct box *pw)
{
int i;
 printf("\nDetails of box record\n");
 for(i=0;i<3;i++)
 {
    printf("\nUnique ID: %d\t Name: %s\n"
        ,pw[i].UID,pw[i].name);
 }
 return *pw;
}

int search_code(struct box *pw)
{
 int c=3;
 int j=0;

 for(int i=0;i<3;i++)
 {
     if(c==pw[i].UID)
       {
         return 3;
       }
       else
        j++;
 }
 if(j==3)
   return 0;
}

    
